using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace SemanticKernelSample;

internal sealed class Worker : BackgroundService
{
    private readonly IHostApplicationLifetime _hostApplicationLifetime;

    public Worker(IHostApplicationLifetime hostApplicationLifetime)
    {
        _hostApplicationLifetime = hostApplicationLifetime;
    }

    protected override async Task ExecuteAsync(
        CancellationToken stoppingToken)
    {
        Console.Write("> ");

        string? input = null;
        while ((input = Console.ReadLine()) != null)
        {
            Console.WriteLine();
            Console.Write($"\n>>> Results: {input}\n\n> ");
        }

        _hostApplicationLifetime.StopApplication();
    }
}