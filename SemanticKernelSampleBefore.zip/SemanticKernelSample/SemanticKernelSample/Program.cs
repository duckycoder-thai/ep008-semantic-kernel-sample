﻿using SemanticKernelSample.Options;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;

namespace SemanticKernelSample;

internal static class Program
{
    internal static async Task Main(string[] args)
    {
        HostApplicationBuilder builder =
            Host.CreateApplicationBuilder(args);

        builder.Services.AddHostedService<Worker>();
        builder.Services.AddOptions<OpenAIOptions>()
            .Bind(builder.Configuration.GetSection("OpenAI"))
            .ValidateDataAnnotations()
            .ValidateOnStart();

        using IHost host = builder.Build();

        await host.RunAsync();
    }
}